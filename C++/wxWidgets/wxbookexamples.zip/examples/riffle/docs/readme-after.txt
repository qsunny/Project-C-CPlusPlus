
Congratulations! You have installed Riffle.

Thank you for using Riffle, and we hope
you enjoy it!

Julian Smart, Anthemion Software Ltd, 2005




Welcome to Riffle!
======================================================

Riffle is a demonstration image browser application for
wxWidgets, included on the CD accompanying the book
"Cross-platform GUI programming with wxWidgets".

For further information, please see the manual, and the
following site:

http://www.wxwidgets.org/book

------------------------------------------------------
Installing Riffle on Windows
------------------------------------------------------

Run Riffle-x.yz-Setup.exe and follow the instructions
to install Riffle.

You should find a shortcut on your desktop, and you can
also find it in a group similar to this:

Start -> Program Files -> Anthemion Riffle x.y

------------------------------------------------------
Installing Riffle on Unix
------------------------------------------------------

Unarchive Riffle-x.yz.tar.gz to a suitable location
in your file system. Run installriffle to complete
the installation; a script 'riffle' will be placed
in the location you choose, for you to run the
program.

------------------------------------------------------
Installing Riffle on Mac OS X
------------------------------------------------------

Clicking on Riffle-x.yz.dmg will mount a folder Riffle.x.yz.
Copy this to a suitable location in your file system
and click on the Riffle icon within the folder.

------------------------------------------------------
(c) Anthemion Software Ltd, 2005


Welcome to Riffle for MacOS 10.3!
=================================================

Riffle is a demonstration image browser application for
wxWidgets, included on the CD accompanying the book
"Cross-platform GUI programming with wxWidgets".

For further information, please see the manual, and the
following site:

http://www.wxwidgets.org/book

Installation
------------
Open the disk image and copy the contained folder to a suitable
place on your hard disk. Then simply double-click on the Riffle icon.

We do hope you enjoy using this software!

------------------------------------------------------
(c) Anthemion Software Ltd, 2005


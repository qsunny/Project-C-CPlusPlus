<HTML>
<head><title>_HELP_TITLE</title></head>

<BODY TOPMARGIN=4 BGCOLOR=#FFFFFF TEXT=#000000 VLINK=#000000 LINK=#000000 ALINK=#000000>
<FONT FACE="Arial, Lucida, Helvetica">

<TABLE WIDTH="100%" ALIGN=CENTER CELLPADDING=1 CELLSPACING=0>
<TR>
<TD WIDTH="100%" ALIGN=CENTER>
#ifdef _HELP_INDEX_FILE
<A HREF=\"_HELP_INDEX_FILE\">
<img align=center src="contents.gif" BORDER=0 ALT="Contents"></A>
#endif

#ifdef _HELP_PARENT_FILE
<A HREF=\"_HELP_PARENT_FILE\">
<img align=center src="up.gif" BORDER=0 ALT="Up"></A>
#endif

#ifdef _HELP_PREVIOUS_FILE
<A HREF=\"_HELP_PREVIOUS_FILE\">
<img align=center src="back.gif" BORDER=0 ALT="Previous"></A>
#endif

#ifdef _HELP_NEXT_FILE
<A HREF=\"_HELP_NEXT_FILE\">
<img align=center src="forward.gif" BORDER=0 ALT="Next"></A>
#endif
</TD>
</TR>
<TR>

<!-- A narrow row representing the horizontal rule -->
<TD COLSPAN=2 HEIGHT=2 BGCOLOR="#C0C0C0">
</TD>
</TR>
</TABLE>

<H2>_HELP_TITLE</H2>